from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
import time
from typing import Any

from mew.ai import DiffusionModelProfile, DiffusionService, GenerationRequest
from mew.ai.diffusion import ProgressCallback

from .models import ANIMAGINE, MODEL_PROFILES, get_profile
from .presets import PromptMode, compose_prompts


@dataclass(frozen=True, slots=True)
class ArtGeneration:
    profile: DiffusionModelProfile
    raw_prompt: str
    raw_negative_prompt: str
    prompt_mode: PromptMode
    request: GenerationRequest
    seed: int
    elapsed_seconds: float
    images: list[Any]


class SuwakoArtService:
    """Own exactly one in-memory diffusion pipeline at a time."""

    def __init__(self, profile: DiffusionModelProfile | str = ANIMAGINE) -> None:
        self._diffusion: DiffusionService | None = None
        self._profile: DiffusionModelProfile | None = None
        self.select_profile(profile)

    @property
    def active_profile(self) -> DiffusionModelProfile:
        assert self._profile is not None
        return self._profile

    @property
    def loaded(self) -> bool:
        return self._diffusion is not None and self._diffusion.loaded

    @staticmethod
    def resolve_profile(profile: DiffusionModelProfile | str) -> DiffusionModelProfile:
        if isinstance(profile, DiffusionModelProfile):
            return profile
        if profile in MODEL_PROFILES:
            return get_profile(profile)
        for candidate in MODEL_PROFILES.values():
            if candidate.model_id == profile:
                return candidate
        raise ValueError(f"Unsupported model profile: {profile}")

    def select_profile(self, profile: DiffusionModelProfile | str) -> DiffusionService:
        resolved = self.resolve_profile(profile)
        if self._profile == resolved and self._diffusion is not None:
            return self._diffusion
        if self._diffusion is not None:
            self._diffusion.unload()
        self._profile = resolved
        self._diffusion = DiffusionService(resolved)
        return self._diffusion

    def is_cached(self, profile: DiffusionModelProfile | str) -> bool:
        resolved = self.resolve_profile(profile)
        if self._profile == resolved and self._diffusion is not None:
            return self._diffusion.is_cached()
        return DiffusionService(resolved).is_cached()

    def cache_directory(self, profile: DiffusionModelProfile | str) -> Path:
        return DiffusionService(self.resolve_profile(profile)).cache_directory

    @staticmethod
    def prepare_request(
        profile: DiffusionModelProfile,
        request: GenerationRequest,
        prompt_mode: PromptMode,
    ) -> GenerationRequest:
        prompt, negative = compose_prompts(
            profile,
            request.prompt,
            request.negative_prompt,
            prompt_mode,
        )
        return replace(request, prompt=prompt, negative_prompt=negative)

    def generate_record(
        self,
        request: GenerationRequest,
        *,
        profile: DiffusionModelProfile | str | None = None,
        prompt_mode: PromptMode = "enhanced",
        progress: ProgressCallback | None = None,
    ) -> ArtGeneration:
        selected = self.resolve_profile(profile or self.active_profile)
        diffusion = self.select_profile(selected)
        prepared = self.prepare_request(selected, request, prompt_mode)
        started = time.perf_counter()
        result = diffusion.generate_result(prepared, progress=progress)
        return ArtGeneration(
            profile=selected,
            raw_prompt=request.prompt,
            raw_negative_prompt=request.negative_prompt,
            prompt_mode=prompt_mode,
            request=prepared,
            seed=result.seed,
            elapsed_seconds=time.perf_counter() - started,
            images=result.images,
        )

    def generate(
        self,
        request: GenerationRequest,
        *,
        prompt_mode: PromptMode = "enhanced",
        progress: ProgressCallback | None = None,
    ) -> list[Any]:
        return self.generate_record(request, prompt_mode=prompt_mode, progress=progress).images

    def compare(
        self,
        prompt: str,
        negative_prompt: str = "",
        *,
        seed: int | None = 0,
        prompt_mode: PromptMode = "enhanced",
        progress_factory: Any | None = None,
    ) -> list[ArtGeneration]:
        actual_seed = DiffusionService.resolve_seed(seed)
        records: list[ArtGeneration] = []
        for profile in MODEL_PROFILES.values():
            request = GenerationRequest(
                prompt=prompt,
                negative_prompt=negative_prompt,
                width=profile.width,
                height=profile.height,
                steps=profile.steps,
                guidance=profile.guidance,
                seed=actual_seed,
                count=1,
            )
            progress = progress_factory(profile) if progress_factory else None
            records.append(
                self.generate_record(
                    request,
                    profile=profile,
                    prompt_mode=prompt_mode,
                    progress=progress,
                )
            )
        return records

    def unload(self) -> None:
        if self._diffusion is not None:
            self._diffusion.unload()

    @staticmethod
    def save(images: list[Any], output_dir: Path, stem: str = "suwako") -> list[Path]:
        """Backward-compatible image-only save helper."""

        output_dir.mkdir(parents=True, exist_ok=True)
        paths: list[Path] = []
        for index, image in enumerate(images, start=1):
            path = output_dir / f"{stem}_{index}.png"
            image.save(path)
            paths.append(path)
        return paths
