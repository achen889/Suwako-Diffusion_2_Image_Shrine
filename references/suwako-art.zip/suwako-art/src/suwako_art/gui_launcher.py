"""Console launcher for the local Streamlit application."""

from __future__ import annotations

from pathlib import Path
import sys


def main() -> int:
    from streamlit.web import cli as streamlit_cli

    app_path = Path(__file__).with_name("gui.py")
    sys.argv = [
        "streamlit",
        "run",
        str(app_path),
        "--server.address=127.0.0.1",
        "--server.headless=false",
    ]
    return int(streamlit_cli.main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())
