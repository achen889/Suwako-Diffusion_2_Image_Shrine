"""Disk-backed Suwako run history."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import uuid
from typing import Any

from .service import ArtGeneration


@dataclass(frozen=True, slots=True)
class SavedRun:
    directory: Path
    metadata_path: Path
    image_paths: list[Path]


def default_output_directory() -> Path:
    return Path.cwd() / "var" / "images" / "suwako"


def save_run(
    generations: list[ArtGeneration],
    output_root: Path,
    *,
    mode: str,
) -> SavedRun:
    created_at = datetime.now(timezone.utc)
    run_id = f"{created_at.strftime('%Y%m%dT%H%M%SZ')}-{uuid.uuid4().hex[:8]}"
    run_directory = output_root / run_id
    run_directory.mkdir(parents=True, exist_ok=False)
    image_paths: list[Path] = []
    generation_metadata: list[dict[str, Any]] = []

    for generation in generations:
        names: list[str] = []
        for index, image in enumerate(generation.images, start=1):
            filename = f"{generation.profile.key}_{index}.png"
            image.save(run_directory / filename)
            image_paths.append(run_directory / filename)
            names.append(filename)
        request_data = asdict(generation.request)
        request_data["seed"] = generation.seed
        generation_metadata.append(
            {
                "profile": generation.profile.key,
                "display_name": generation.profile.display_name,
                "model_id": generation.profile.model_id,
                "revision": generation.profile.revision,
                "pipeline_family": generation.profile.pipeline_family,
                "scheduler": generation.profile.scheduler,
                "prompt_mode": generation.prompt_mode,
                "raw_prompt": generation.raw_prompt,
                "raw_negative_prompt": generation.raw_negative_prompt,
                "composed_prompt": generation.request.prompt,
                "composed_negative_prompt": generation.request.negative_prompt,
                "request": request_data,
                "elapsed_seconds": round(generation.elapsed_seconds, 3),
                "images": names,
            }
        )

    metadata = {
        "schema_version": 1,
        "run_id": run_id,
        "created_at": created_at.isoformat(),
        "mode": mode,
        "generations": generation_metadata,
    }
    metadata_path = run_directory / "metadata.json"
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    return SavedRun(run_directory, metadata_path, image_paths)


def load_recent_runs(output_root: Path, limit: int = 20) -> list[dict[str, Any]]:
    if not output_root.is_dir():
        return []
    metadata_paths = sorted(
        output_root.glob("*/metadata.json"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    runs: list[dict[str, Any]] = []
    for path in metadata_paths[:limit]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        data["_directory"] = str(path.parent)
        runs.append(data)
    return runs
