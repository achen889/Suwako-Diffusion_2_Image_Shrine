"""Supported, pinned diffusion model profiles."""

from __future__ import annotations

from types import MappingProxyType

from mew.ai import DiffusionModelProfile


ANIMAGINE = DiffusionModelProfile(
    key="animagine",
    display_name="Animagine XL 4.0",
    model_id="cagliostrolab/animagine-xl-4.0",
    revision="2b7c1b397761bf5bd3cc42e5b39ec99314a75a96",
    pipeline_family="sdxl",
    scheduler="euler_ancestral",
    width=1024,
    height=1024,
    steps=28,
    guidance=5.0,
    count=4,
    prompt_suffix="masterpiece, high score, great score, absurdres",
    negative_prompt=(
        "lowres, bad anatomy, bad hands, text, error, missing finger, extra digits, "
        "fewer digits, cropped, worst quality, low quality, low score, bad score, "
        "average score, signature, watermark, username, blurry"
    ),
    license_url="https://huggingface.co/cagliostrolab/animagine-xl-4.0",
)

WAIFU = DiffusionModelProfile(
    key="waifu",
    display_name="Waifu Diffusion 1.5 Beta 2",
    model_id="waifu-diffusion/wd-1-5-beta2",
    revision="552da11",
    pipeline_family="sd15",
    scheduler="euler_ancestral",
    width=512,
    height=512,
    steps=25,
    guidance=7.0,
    count=4,
    prompt_prefix="masterpiece, best quality",
    negative_prompt=(
        "worst quality, low quality, lowres, bad anatomy, bad hands, text, error, "
        "missing fingers, extra digits, fewer digits, cropped, jpeg artifacts, "
        "signature, watermark, username, blurry"
    ),
    license_url="https://huggingface.co/waifu-diffusion/wd-1-5-beta2",
)

MODEL_PROFILES = MappingProxyType({profile.key: profile for profile in (ANIMAGINE, WAIFU)})


def get_profile(key: str) -> DiffusionModelProfile:
    try:
        return MODEL_PROFILES[key]
    except KeyError as error:
        choices = ", ".join(MODEL_PROFILES)
        raise ValueError(f"Unknown model profile {key!r}; choose one of: {choices}") from error
