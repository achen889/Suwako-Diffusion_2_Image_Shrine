"""Prompt composition shared by the CLI and GUI."""

from __future__ import annotations

from typing import Literal

from mew.ai import DiffusionModelProfile

from .models import ANIMAGINE


PromptMode = Literal["exact", "enhanced"]
DEFAULT_PREFIX = ANIMAGINE.prompt_prefix
DEFAULT_NEGATIVE_PROMPT = ANIMAGINE.negative_prompt


def _join_prompt_parts(*parts: str) -> str:
    return ", ".join(part.strip(" ,") for part in parts if part.strip(" ,"))


def compose_prompts(
    profile: DiffusionModelProfile,
    prompt: str,
    negative_prompt: str = "",
    mode: PromptMode = "enhanced",
) -> tuple[str, str]:
    prompt = prompt.strip()
    negative_prompt = negative_prompt.strip()
    if mode == "exact":
        return prompt, negative_prompt
    if mode != "enhanced":
        raise ValueError(f"Unknown prompt mode: {mode}")
    return (
        _join_prompt_parts(profile.prompt_prefix, prompt, profile.prompt_suffix),
        _join_prompt_parts(profile.negative_prompt, negative_prompt),
    )


def compose_prompt(prompt: str, prefix: str = DEFAULT_PREFIX) -> str:
    """Backward-compatible prompt helper."""

    return _join_prompt_parts(prefix, prompt)
