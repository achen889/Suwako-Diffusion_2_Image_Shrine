"""Streamlit interface for Suwako Art."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from mew.ai import GenerationRequest, huggingface_cache_home

from .history import default_output_directory, load_recent_runs, save_run
from .models import MODEL_PROFILES, get_profile
from .presets import compose_prompts
from .service import SuwakoArtService


@st.cache_resource
def get_service() -> SuwakoArtService:
    return SuwakoArtService()


def _show_saved_run(directory: Path) -> None:
    runs = load_recent_runs(directory.parent, limit=50)
    run = next((item for item in runs if Path(item["_directory"]) == directory), None)
    if run is None:
        return
    st.caption(f"Saved to {directory}")
    for generation in run.get("generations", []):
        st.subheader(generation.get("display_name", generation.get("profile", "Result")))
        columns = st.columns(min(4, max(1, len(generation.get("images", [])))))
        for index, filename in enumerate(generation.get("images", [])):
            image_path = directory / filename
            if image_path.is_file():
                columns[index % len(columns)].image(str(image_path), caption=filename, use_container_width=True)
        st.caption(
            f"Seed {generation.get('request', {}).get('seed')} · "
            f"{generation.get('elapsed_seconds', 0)} seconds"
        )


def _show_recent_gallery(output_root: Path) -> None:
    runs = load_recent_runs(output_root)
    if not runs:
        st.info("No saved Suwako generations yet.")
        return
    for run in runs:
        with st.expander(f"{run.get('created_at', 'Unknown time')} · {run.get('mode', 'generation')}"):
            _show_saved_run(Path(run["_directory"]))


def main() -> None:
    st.set_page_config(page_title="Suwako Art", page_icon="🎨", layout="wide")
    st.title("Suwako Art")
    st.caption("Local CUDA anime art with on-demand, persistent Hugging Face model caching")

    service = get_service()
    output_root = default_output_directory()
    profile_key = st.selectbox(
        "Model",
        options=list(MODEL_PROFILES),
        format_func=lambda key: get_profile(key).display_name,
    )
    profile = get_profile(profile_key)
    cached = service.is_cached(profile)
    if cached:
        st.success(f"Cached on disk: {service.cache_directory(profile)}")
    else:
        st.warning(
            "This model is not cached. Generate or Compare will download it once into "
            f"{huggingface_cache_home()}; selecting it alone downloads nothing."
        )
    st.caption(f"Pinned revision: {profile.revision} · [Model and license]({profile.license_url})")

    prompt = st.text_area("Prompt", height=180, placeholder="Paste the diffusion prompt developed in chat here")
    negative_prompt = st.text_area("Additional negative prompt", height=100)
    prompt_mode = st.radio("Prompt handling", ("enhanced", "exact"), horizontal=True)
    composed_prompt, composed_negative = compose_prompts(profile, prompt, negative_prompt, prompt_mode)
    with st.expander("Final composed prompts", expanded=True):
        st.text_area("Composed prompt", composed_prompt, height=120, disabled=True)
        st.text_area("Composed negative prompt", composed_negative, height=100, disabled=True)

    with st.expander("Generation settings"):
        count = st.slider("Images", 1, 4, profile.count, key=f"count-{profile.key}")
        width = st.number_input("Width", 256, 2048, profile.width, 64, key=f"width-{profile.key}")
        height = st.number_input("Height", 256, 2048, profile.height, 64, key=f"height-{profile.key}")
        steps = st.slider("Steps", 1, 60, profile.steps, key=f"steps-{profile.key}")
        guidance = st.slider("Guidance", 1.0, 15.0, profile.guidance, 0.5, key=f"guidance-{profile.key}")
        random_seed = st.checkbox("Random seed", value=True)
        seed_value = st.number_input("Seed", 1, 2**31 - 1, 1, disabled=random_seed)
    seed = 0 if random_seed else int(seed_value)

    generate_column, compare_column = st.columns(2)
    if generate_column.button(f"Generate {count} image{'s' if count != 1 else ''}", type="primary", use_container_width=True):
        if not prompt.strip():
            st.error("Enter a prompt first.")
        else:
            progress_bar = st.progress(0.0, text="Preparing model…")

            def report(step: int, total: int) -> None:
                progress_bar.progress(step / total, text=f"Generating {step}/{total} steps")

            try:
                request = GenerationRequest(
                    prompt=prompt,
                    negative_prompt=negative_prompt,
                    width=int(width),
                    height=int(height),
                    steps=steps,
                    guidance=guidance,
                    seed=seed,
                    count=count,
                )
                generation = service.generate_record(
                    request,
                    profile=profile,
                    prompt_mode=prompt_mode,
                    progress=report,
                )
                saved = save_run([generation], output_root, mode="generation")
                st.session_state["suwako_last_run"] = str(saved.directory)
                progress_bar.progress(1.0, text="Complete")
            except Exception as error:
                st.exception(error)

    if compare_column.button("Compare both models (1 each)", use_container_width=True):
        if not prompt.strip():
            st.error("Enter a prompt first.")
        else:
            progress_bar = st.progress(0.0, text="Preparing comparison…")
            profile_order = list(MODEL_PROFILES)

            def progress_factory(current_profile):
                model_index = profile_order.index(current_profile.key)

                def report(step: int, total: int) -> None:
                    fraction = (model_index + step / total) / len(profile_order)
                    progress_bar.progress(
                        fraction,
                        text=f"{current_profile.display_name}: {step}/{total} steps",
                    )

                return report

            try:
                generations = service.compare(
                    prompt,
                    negative_prompt,
                    seed=seed,
                    prompt_mode=prompt_mode,
                    progress_factory=progress_factory,
                )
                saved = save_run(generations, output_root, mode="comparison")
                st.session_state["suwako_last_run"] = str(saved.directory)
                progress_bar.progress(1.0, text="Comparison complete")
            except Exception as error:
                st.exception(error)

    last_run = st.session_state.get("suwako_last_run")
    if last_run:
        st.divider()
        _show_saved_run(Path(last_run))

    st.divider()
    st.header("Recent gallery")
    _show_recent_gallery(output_root)


if __name__ == "__main__":
    main()
