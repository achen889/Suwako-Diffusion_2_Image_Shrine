from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path

from mew.ai import DiffusionModelProfile, GenerationRequest

from .history import default_output_directory, save_run
from .models import ANIMAGINE, MODEL_PROFILES, get_profile
from .service import SuwakoArtService


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate local anime art with cached diffusion models")
    parser.add_argument("prompt", nargs="?")
    parser.add_argument("--negative-prompt", default="")
    parser.add_argument("--profile", choices=MODEL_PROFILES, default="animagine")
    parser.add_argument("--model", help="Advanced compatibility override for a Hugging Face repository ID")
    parser.add_argument("--revision")
    parser.add_argument("--prompt-mode", choices=("exact", "enhanced"), default="enhanced")
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--steps", type=int)
    parser.add_argument("--guidance", type=float)
    parser.add_argument("--seed", type=int, default=0, help="Use 0 to choose and record a random seed")
    parser.add_argument("--count", type=int)
    parser.add_argument("--compare", action="store_true", help="Generate one image from each built-in model")
    parser.add_argument("--status", action="store_true", help="Show local cache status without loading a model")
    parser.add_argument("--output", type=Path, default=default_output_directory())
    return parser


def _selected_profile(args: argparse.Namespace) -> DiffusionModelProfile:
    profile = get_profile(args.profile)
    if not args.model:
        return profile
    for candidate in MODEL_PROFILES.values():
        if candidate.model_id == args.model:
            return candidate
    return replace(
        ANIMAGINE,
        key="custom",
        display_name=args.model,
        model_id=args.model,
        revision=args.revision or "main",
        pipeline_family="auto",
    )


def main() -> int:
    args = build_parser().parse_args()
    service = SuwakoArtService()
    if args.status:
        profile = _selected_profile(args)
        print(f"profile={profile.key}")
        print(f"model_id={profile.model_id}")
        print(f"revision={profile.revision}")
        print(f"cached={str(service.is_cached(profile)).lower()}")
        print(f"cache_directory={service.cache_directory(profile)}")
        return 0
    if not args.prompt:
        build_parser().error("prompt is required unless --status is used")
    if args.compare:
        generations = service.compare(
            args.prompt,
            args.negative_prompt,
            seed=args.seed,
            prompt_mode=args.prompt_mode,
        )
        mode = "comparison"
    else:
        profile = _selected_profile(args)
        request = GenerationRequest(
            prompt=args.prompt,
            negative_prompt=args.negative_prompt,
            width=args.width or profile.width,
            height=args.height or profile.height,
            steps=args.steps or profile.steps,
            guidance=args.guidance if args.guidance is not None else profile.guidance,
            seed=args.seed,
            count=args.count or profile.count,
        )
        generations = [
            service.generate_record(
                request,
                profile=profile,
                prompt_mode=args.prompt_mode,
            )
        ]
        mode = "generation"

    saved = save_run(generations, args.output, mode=mode)
    for path in saved.image_paths:
        print(path.resolve())
    print(saved.metadata_path.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
